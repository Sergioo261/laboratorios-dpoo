package uniandes.dpoo.aerolinea.tiquetes;

import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;
import uniandes.dpoo.aerolinea.modelo.tarifas.CalculadoraTarifas;

public class Tiquete {
    
    private String codigo;
    private int tarifa;
    private boolean usado;
    private Vuelo vuelo;
    private Cliente clienteComprador;

    /**
     * Constructor de la clase Tiquete.
     * @param codigo Código único del tiquete.
     * @param vuelo Vuelo asociado al tiquete.
     * @param clienteComprador Cliente que compró el tiquete.
     * @param tarifa Tarifa del tiquete.
     */
    public Tiquete(String codigo, Vuelo vuelo, Cliente clienteComprador, int tarifa) {
        this.codigo = codigo;
        this.vuelo = vuelo;
        this.clienteComprador = clienteComprador;
        this.tarifa = tarifa;
        this.usado = false;
    }

    public Tiquete(Cliente cliente, Vuelo vuelo2, CalculadoraTarifas calculadora) {
		// TODO Auto-generated constructor stub
	}

	/**
     * Devuelve el cliente que compró el tiquete.
     * @return Cliente comprador.
     */
    public Cliente getCliente() {
        return clienteComprador;
    }

    /**
     * Devuelve el vuelo asociado al tiquete.
     * @return Vuelo del tiquete.
     */
    public Vuelo getVuelo() {
        return vuelo;
    }

    /**
     * Devuelve el código del tiquete.
     * @return Código del tiquete.
     */
    public String getCodigo() {
        return codigo;
    }

    /**
     * Devuelve la tarifa del tiquete.
     * @return Tarifa del tiquete.
     */
    public int getTarifa() {
        return tarifa;
    }

    /**
     * Marca el tiquete como usado.
     */
    public void marcarComoUsado() {
        this.usado = true;
    }

    /**
     * Indica si el tiquete ha sido usado.
     * @return true si ha sido usado, false en caso contrario.
     */
    public boolean esUsado() {
        return usado;
    }

	public int getPrecio() {
		return 0;
	}
}

