package uniandes.dpoo.aerolinea.modelo;

/**
 * Esta clase tiene la información de una ruta entre dos aeropuertos que cubre una aerolínea.
 */
public class Ruta {
    // Atributos
    private String horaSalida;
    private String horaLlegada;
    private String codigoRuta;
    private Aeropuerto origen;
    private Aeropuerto destino;

    /**
     * Constructor de la clase Ruta
     * @param origen Aeropuerto de origen
     * @param destino Aeropuerto de destino
     * @param horaSalida Hora de salida en formato HHMM
     * @param horaLlegada Hora de llegada en formato HHMM
     * @param codigoRuta Código único de la ruta
     */
    public Ruta(Aeropuerto origen, Aeropuerto destino, String horaSalida, String horaLlegada, String codigoRuta) {
        this.origen = origen;
        this.destino = destino;
        this.horaSalida = horaSalida;
        this.horaLlegada = horaLlegada;
        this.codigoRuta = codigoRuta;
    }

    /**
     * @return El código de la ruta
     */
    public String getCodigoRuta() {
        return codigoRuta;
    }

    /**
     * @return El aeropuerto de origen
     */
    public Aeropuerto getOrigen() {
        return origen;
    }

    /**
     * @return El aeropuerto de destino
     */
    public Aeropuerto getDestino() {
        return destino;
    }

    /**
     * @return La hora de salida en formato HHMM
     */
    public String getHoraSalida() {
        return horaSalida;
    }

    /**
     * @return La hora de llegada en formato HHMM
     */
    public String getHoraLlegada() {
        return horaLlegada;
    }

    /**
     * Calcula la duración del vuelo en minutos
     * @return Duración del vuelo en minutos
     */
    public int getDuracion() {
        int horasSalida = getHoras(horaSalida);
        int minutosSalida = getMinutos(horaSalida);
        int horasLlegada = getHoras(horaLlegada);
        int minutosLlegada = getMinutos(horaLlegada);

        int tiempoSalida = horasSalida * 60 + minutosSalida;
        int tiempoLlegada = horasLlegada * 60 + minutosLlegada;

        // Si la llegada es el día siguiente
        if (tiempoLlegada < tiempoSalida) {
            tiempoLlegada += 24 * 60;
        }

        return tiempoLlegada - tiempoSalida;
    }

    /**
     * Extrae los minutos de una hora en formato HHMM
     * @param horaCompleta Hora en formato HHMM
     * @return Minutos entre 0 y 59
     */
    public static int getMinutos(String horaCompleta) {
        return Integer.parseInt(horaCompleta) % 100;
    }

    /**
     * Extrae las horas de una hora en formato HHMM
     * @param horaCompleta Hora en formato HHMM
     * @return Horas entre 0 y 23
     */
    public static int getHoras(String horaCompleta) {
        return Integer.parseInt(horaCompleta) / 100;
    }

	public int getDistancia() {
		// TODO Auto-generated method stub
		return 0;
	}
}

