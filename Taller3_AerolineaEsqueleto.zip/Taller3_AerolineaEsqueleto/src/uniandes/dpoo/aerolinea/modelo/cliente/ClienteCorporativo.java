package uniandes.dpoo.aerolinea.modelo.cliente;

import org.json.JSONObject;

/**
 * Esta clase se usa para representar a los clientes de la aerolínea que son empresas.
 */
public class ClienteCorporativo extends Cliente {
    
    public static final String CORPORATIVO = "Corporativo";
    public static final int GRANDE = 1;
    public static final int MEDIANA = 2;
    public static final int PEQUENA = 3;

    private String nombreEmpresa;
    private int tamanoEmpresa;

    /**
     * Constructor de ClienteCorporativo.
     * @param nombreEmpresa Nombre de la empresa.
     * @param tamano Tamaño de la empresa (GRANDE, MEDIANA o PEQUENA).
     */
    public ClienteCorporativo(String nombreEmpresa, int tamano) {
        this.nombreEmpresa = nombreEmpresa;
        this.tamanoEmpresa = tamano;
    }

    /**
     * Devuelve el nombre de la empresa.
     * @return Nombre de la empresa.
     */
    public String getNombreEmpresa() {
        return nombreEmpresa;
    }

    /**
     * Devuelve el tamaño de la empresa.
     * @return Tamaño de la empresa (1=GRANDE, 2=MEDIANA, 3=PEQUENA).
     */
    public int getTamanoEmpresa() {
        return tamanoEmpresa;
    }

    /**
     * Retorna el tipo de cliente corporativo.
     * @return "Corporativo".
     */
    public String getTipoCliente() {
        return CORPORATIVO;
    }

    /**
     * Retorna un identificador único del cliente corporativo (nombre de la empresa).
     * @return Identificador del cliente.
     */
    @Override
    public String getIdentificador() {
        return nombreEmpresa;
    }

    /**
     * Crea un objeto ClienteCorporativo a partir de un JSONObject.
     * @param cliente El objeto JSON con la información del cliente.
     * @return ClienteCorporativo con los datos cargados.
     */
    public static ClienteCorporativo cargarDesdeJSON(JSONObject cliente) {
        String nombreEmpresa = cliente.getString("nombreEmpresa");
        int tam = cliente.getInt("tamanoEmpresa");
        return new ClienteCorporativo(nombreEmpresa, tam);
    }

    /**
     * Guarda la información del cliente en un JSONObject.
     * @return JSONObject con los datos del cliente.
     */
    public JSONObject salvarEnJSON() {
        JSONObject jobject = new JSONObject();
        jobject.put("nombreEmpresa", this.nombreEmpresa);
        jobject.put("tamanoEmpresa", this.tamanoEmpresa);
        jobject.put("tipo", CORPORATIVO);
        return jobject;
    }

	@Override
	protected boolean esCorporativo() {
		// TODO Auto-generated method stub
		return false;
	}
}
