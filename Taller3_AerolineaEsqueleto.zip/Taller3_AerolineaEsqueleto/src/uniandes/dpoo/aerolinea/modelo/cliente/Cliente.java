package uniandes.dpoo.aerolinea.modelo.cliente;

import java.util.ArrayList;
import java.util.List;

import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.tiquetes.Tiquete;

/**
 * Clase abstracta que representa a un cliente de la aerolínea.
 */
public abstract class Cliente {

    protected List<Tiquete> tiquetes;

    /**
     * Constructor de la clase Cliente.
     * Inicializa la lista de tiquetes.
     */
    public Cliente() {
        this.tiquetes = new ArrayList<>();
    }

    /**
     * Retorna el identificador único del cliente.
     * @return Identificador del cliente.
     */
    public abstract String getIdentificador();

    /**
     * Retorna el tipo de cliente (por ejemplo, "Natural" o "Corporativo").
     * @return Tipo de cliente.
     */
    public abstract String getTipoCliente();

    /**
     * Agrega un tiquete a la lista de tiquetes del cliente.
     * @param tiquete Tiquete a agregar.
     */
    public void agregarTiquete(Tiquete tiquete) {
        tiquetes.add(tiquete);
    }

    /**
     * Calcula el valor total de todos los tiquetes del cliente.
     * @return Suma del valor de los tiquetes.
     */
    public int calcularValorTotalTiquetes() {
        int total = 0;
        for (Tiquete t : tiquetes) {
            total += t.getPrecio();
        }
        return total;
    }

    /**
     * Usa los tiquetes asociados a un vuelo.
     * @param vuelo Vuelo para el cual se usan los tiquetes.
     */
    public void usarTiquetes(Vuelo vuelo) {
        tiquetes.removeIf(tiquete -> tiquete.getVuelo().equals(vuelo));
    }

	public int getHistorialCompras() {
		// TODO Auto-generated method stub
		return 0;
	}

	protected abstract boolean esCorporativo();
}