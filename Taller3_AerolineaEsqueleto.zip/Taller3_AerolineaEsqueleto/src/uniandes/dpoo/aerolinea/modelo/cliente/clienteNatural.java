package uniandes.dpoo.aerolinea.modelo.cliente;

/**
 * Representa un cliente natural de la aerolínea.
 */
public class clienteNatural extends Cliente {

    public static final String NATURAL = "Natural";
    private String nombre;

    /**
     * Constructor de ClienteNatural.
     * @param nombre Nombre del cliente.
     */
    public clienteNatural(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Retorna el identificador del cliente natural (su nombre).
     * @return Nombre del cliente.
     */
    @Override
    public String getIdentificador() {
        return nombre;
    }

    /**
     * Retorna el tipo de cliente.
     * @return "Natural".
     */
    @Override
    public String getTipoCliente() {
        return NATURAL;
    }

	@Override
	protected boolean esCorporativo() {
		// TODO Auto-generated method stub
		return false;
	}
}
