package uniandes.dpoo.aerolinea.modelo;

import java.util.ArrayList;
import java.util.Collection;

import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;
import uniandes.dpoo.aerolinea.modelo.tarifas.CalculadoraTarifas;
import uniandes.dpoo.aerolinea.tiquetes.Tiquete;

public class Vuelo {
    private String fecha;
    private Ruta ruta;
    private Avion avion;
    private Collection<Tiquete> tiquetes;

    /**
     * Constructor de la clase Vuelo.
     * 
     * @param ruta  Ruta del vuelo.
     * @param fecha Fecha del vuelo.
     * @param avion Avión asignado al vuelo.
     */
    public Vuelo(Ruta ruta, String fecha, Avion avion) {
        this.ruta = ruta;
        this.fecha = fecha;
        this.avion = avion;
        this.tiquetes = new ArrayList<>();
    }

    public Vuelo(String fecha2, Ruta ruta2, Avion avion2) {

	}

	/**
     * Retorna la ruta del vuelo.
     * 
     * @return Ruta del vuelo.
     */
    public Ruta getRuta() {
        return ruta;
    }

    /**
     * Retorna la fecha del vuelo.
     * 
     * @return Fecha del vuelo.
     */
    public String getFecha() {
        return fecha;
    }

    /**
     * Retorna el avión asignado al vuelo.
     * 
     * @return Avión del vuelo.
     */
    public Avion getAvion() {
        return avion;
    }

    /**
     * Retorna la colección de tiquetes vendidos en el vuelo.
     * 
     * @return Colección de tiquetes.
     */
    public Collection<Tiquete> getTiquetes() {
        return tiquetes;
    }

    /**
     * Vende tiquetes para el vuelo a un cliente.
     * 
     * @param cliente    Cliente que compra los tiquetes.
     * @param calculadora Calculadora de tarifas para determinar el precio.
     * @param cantidad   Número de tiquetes a vender.
     * @return Cantidad de tiquetes efectivamente vendidos.
     */
	public int venderTiquetes(Cliente cliente, int cantidad) {
        if (cantidad <= 0 || cantidad > avion.getCapacidad() - tiquetes.size()) {
            return 0; // No se pueden vender más tiquetes de los disponibles
        }

        for (int i = 0; i < cantidad; i++) {
            CalculadoraTarifas calculadora = null;
			Tiquete tiquete = new Tiquete(cliente, this, calculadora);
            tiquetes.add(tiquete);
        }

        return cantidad;
	}

    /**
     * Compara si dos vuelos son iguales según su fecha, ruta y avión.
     * 
     * @param obj Objeto a comparar.
     * @return true si son iguales, false de lo contrario.
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Vuelo otroVuelo = (Vuelo) obj;
        return fecha.equals(otroVuelo.fecha) && ruta.equals(otroVuelo.ruta) && avion.equals(otroVuelo.avion);
    }

	public Object getCodigoRuta() {

		return null;
	}

}

