package uniandes.dpoo.aerolinea.modelo;

public class Avion {
    private String nombre;
    private int capacidad;

    /**
     * Constructor de la clase Avion.
     * @param nombre Nombre del avión.
     * @param capacidad Capacidad máxima de pasajeros.
     */
    public Avion(String nombre, int capacidad) {
        this.nombre = nombre;
        this.capacidad = capacidad;
    }

    /**
     * Retorna el nombre del avión.
     * @return Nombre del avión.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Retorna la capacidad del avión.
     * @return Capacidad máxima del avión.
     */
    public int getCapacidad() {
        return capacidad;
    }
}
