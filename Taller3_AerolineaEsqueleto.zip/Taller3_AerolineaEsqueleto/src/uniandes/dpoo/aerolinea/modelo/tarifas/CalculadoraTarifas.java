package uniandes.dpoo.aerolinea.modelo.tarifas;

import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.modelo.Ruta;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;

public abstract class CalculadoraTarifas {
    public static final double IMPUESTO = 0.28;

    /**
     * Calcula la tarifa de un vuelo para un cliente.
     * 
     * @param vuelo   El vuelo en cuestión.
     * @param cliente El cliente que compra el tiquete.
     * @return El costo final del tiquete.
     */
    public int calcularTarifa(Vuelo vuelo, Cliente cliente) {
        int costoBase = calcularCostoBase(vuelo, cliente);
        double descuento = calcularPorcentajeDescuento(cliente);
        int valorImpuestos = calcularValorImpuestos(costoBase);

        return (int) ((costoBase - (costoBase * descuento)) + valorImpuestos);
    }

    /**
     * Calcula el costo base del vuelo para un cliente.
     * 
     * @param vuelo   El vuelo en cuestión.
     * @param cliente El cliente que compra el tiquete.
     * @return El costo base del vuelo.
     */
    protected abstract int calcularCostoBase(Vuelo vuelo, Cliente cliente);

    /**
     * Calcula el porcentaje de descuento aplicable a un cliente.
     * 
     * @param cliente El cliente que compra el tiquete.
     * @return El porcentaje de descuento.
     */
    protected abstract double calcularPorcentajeDescuento(Cliente cliente);

    /**
     * Calcula la distancia del vuelo basado en su ruta.
     * 
     * @param ruta La ruta del vuelo.
     * @return La distancia del vuelo en kilómetros.
     */
    protected abstract int calcularDistanciaVuelo(Ruta ruta);

    /**
     * Calcula el valor de los impuestos sobre el costo base.
     * 
     * @param costoBase El costo base del vuelo.
     * @return El valor de los impuestos a pagar.
     */
    protected int calcularValorImpuestos(int costoBase) {
        return (int) (costoBase * IMPUESTO);
    }
}
