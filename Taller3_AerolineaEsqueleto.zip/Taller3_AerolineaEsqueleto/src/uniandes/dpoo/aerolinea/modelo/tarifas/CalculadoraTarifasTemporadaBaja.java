package uniandes.dpoo.aerolinea.modelo.tarifas;

import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.modelo.Ruta;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;

/**
 * Clase que implementa la calculadora de tarifas para temporada baja.
 */
public class CalculadoraTarifasTemporadaBaja extends CalculadoraTarifas {
    private static final int COSTO_POR_KM_NATURAL = 600;
    private static final int COSTO_POR_KM_CORPORATIVO = 900;
    private static final double DESCUENTO_PEQ = 0.02;
    private static final double DESCUENTO_MEDIANAS = 0.1;
    private static final double DESCUENTO_GRANDES = 0.2;

    @Override
    protected int calcularCostoBase(Vuelo vuelo, Cliente cliente) {
        int costoPorKm = cliente.esCorporativo() ? COSTO_POR_KM_CORPORATIVO : COSTO_POR_KM_NATURAL;
        int distancia = calcularDistanciaVuelo(vuelo.getRuta());
        return costoPorKm * distancia;
    }

    @Override
    protected double calcularPorcentajeDescuento(Cliente cliente) {
        int historial = cliente.getHistorialCompras();
        if (historial > 50) return DESCUENTO_GRANDES;
        else if (historial > 20) return DESCUENTO_MEDIANAS;
        else if (historial > 5) return DESCUENTO_PEQ;
        return 0;
    }

    @Override
    protected int calcularDistanciaVuelo(Ruta ruta) {
        return ruta.getDistancia();
    }
}
